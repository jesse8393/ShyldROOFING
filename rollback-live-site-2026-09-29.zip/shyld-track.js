/* SHYLD Roofing conversion tracking v1.4 2026-06-24. No GA4/GTM IDs hardcoded; pushes to window.dataLayer. */
(function(){
'use strict';
var DL=(window.dataLayer=window.dataLayer||[]);
var DEBUG=(location.search.indexOf('ttdebug=1')>-1)||(function(){try{return localStorage.getItem('shyld_track_debug')==='1';}catch(e){return false;}})();
function log(){if(DEBUG&&window.console){try{console.log.apply(console,['[shyld-track]'].concat([].slice.call(arguments)));}catch(e){}}}
var UTM=['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','gbraid','wbraid'];
function captureUTM(){try{var qs=new URLSearchParams(location.search),found={},any=false;UTM.forEach(function(k){var v=qs.get(k);if(v){found[k]=v;any=true;}});if(any){var st={};try{st=JSON.parse(localStorage.getItem('shyld_utm')||'{}');}catch(e){}UTM.forEach(function(k){if(found[k])st[k]=found[k];});st._ts=Date.now();var s=JSON.stringify(st);try{localStorage.setItem('shyld_utm',s);}catch(e){}try{sessionStorage.setItem('shyld_utm',s);}catch(e){}}}catch(e){log('utm err',e);}}
function captureLanding(){try{if(!localStorage.getItem('shyld_landing')){localStorage.setItem('shyld_landing',location.pathname);}}catch(e){}}
function getUTM(){try{return JSON.parse(sessionStorage.getItem('shyld_utm')||localStorage.getItem('shyld_utm')||'{}');}catch(e){return {};}}
function getLanding(){try{return localStorage.getItem('shyld_landing')||'';}catch(e){return '';}}
function starts(p,s){return p.lastIndexOf(s,0)===0;}
function low(x){return (x||'').toLowerCase();}
function ctxFor(){var p=location.pathname;while(p.length>1&&p.charAt(p.length-1)==='/'){p=p.slice(0,-1);}var c={page_path:location.pathname,page_type:'other',service:null,city:null};var svc=['roof-replacement','roof-repair','storm-restoration','metal-roofing','siding','gutters','storm-damage-roof-inspection','hail-damage-roof-inspection','wind-damage-roof-repair','roof-leak-emergency','insurance-roof-inspection-middle-tn'];if(p===''||p==='/'){c.page_type='home';}else if(starts(p,'/privacy')||starts(p,'/terms')||starts(p,'/text-us')){c.page_type='legal';}else if(starts(p,'/roofing-')){c.page_type='city';c.city=p.slice(9);}else{for(var i=0;i<svc.length;i++){if(starts(p,'/'+svc[i])){c.page_type='service';c.service=svc[i];break;}}}return c;}
function push(name,extra){try{var c=ctxFor();var payload=Object.assign({event:name},c,{utm:getUTM()},extra||{});DL.push(payload);log(name,payload);}catch(e){log('push err',e);}}
function pos(el){try{if(el.closest('.shyld-mbar'))return 'mobile_sticky';if(el.closest('header,.site-head,.header'))return 'header';if(el.closest('.hero,#hero'))return 'hero';if(el.closest('.shyld-ts,.shyld-tp'))return 'trust';if(el.closest('footer,.site-foot,.footer'))return 'footer';}catch(e){}return 'body';}
function attrMap(form){var u=getUTM(),c=ctxFor();var hero=!!(form&&form.closest&&form.closest('.hero,#hero'));return {utm_source:u.utm_source,utm_medium:u.utm_medium,utm_campaign:u.utm_campaign,utm_term:u.utm_term,utm_content:u.utm_content,gclid:u.gclid,gbraid:u.gbraid,wbraid:u.wbraid,landing_page:getLanding()||c.page_path,page_path:c.page_path,page_type:c.page_type,city:c.city,form_id:(form&&form.id)||'',cta_position:hero?'hero':'body',service:c.service||''};}
function injectHidden(form){try{var m=attrMap(form);Object.keys(m).forEach(function(k){var v=m[k];if(v==null||v==='')return;if(form.querySelector('[name="'+k+'"]'))return;var i=document.createElement('input');i.type='hidden';i.name=k;i.value=String(v);form.appendChild(i);});}catch(e){log('inject err',e);}}
function injectAll(){try{var fs=document.querySelectorAll('form');for(var i=0;i<fs.length;i++)injectHidden(fs[i]);}catch(e){}}
var _f=window.fetch;
window.fetch=function(input,init){try{var url=(typeof input==='string')?input:(input&&input.url)||'';if(url.indexOf('shyld-ai-agents.vercel.app/api/form-intake')>-1&&init&&String(init.method||'').toUpperCase()==='POST'&&init.body){var m=attrMap(null);if(init.body instanceof FormData){Object.keys(m).forEach(function(k){if(m[k]!=null&&m[k]!==''&&!init.body.has(k))init.body.append(k,String(m[k]));});}else if(typeof init.body==='string'){try{var o=JSON.parse(init.body);Object.keys(m).forEach(function(k){if((o[k]==null||o[k]==='')&&m[k]!=null&&m[k]!=='')o[k]=String(m[k]);});init.body=JSON.stringify(o);}catch(e){}}}}catch(e){log('fetchwrap err',e);}return _f.apply(this,arguments);};
var CTA_RE=new RegExp('free inspection|schedule|get a quote|get quote|request|claim','i');
document.addEventListener('click',function(e){try{var a=e.target.closest&&e.target.closest('a,button');if(!a)return;var href=low(a.getAttribute('href'));var c=ctxFor();var P=a.getAttribute('data-cta-position')||pos(a);var de=a.getAttribute('data-event');var name=null;
if(de){name=de;}
else if(starts(href,'tel:')){name=(P==='mobile_sticky'?'mobile_sticky_call':P==='header'?'header_call_click':P==='hero'?'hero_call_click':P+'_call_click');}
else if(starts(href,'sms:')){name=(P==='mobile_sticky'?'mobile_sticky_text':P==='header'?'header_text_click':P+'_text_click');}
else if(low(href).indexOf('financing')>-1||low(a.textContent).indexOf('financing')>-1){name='financing_cta_click';}
else if(href.indexOf('#contact')>-1||href.indexOf('#book')>-1||href.indexOf('#form')>-1||CTA_RE.test(a.textContent||'')){name=(c.page_type==='city'?'city_page_cta_click':c.page_type==='service'?'service_page_cta_click':'hero_cta_click');}
if(!name)return;push(name,{cta_position:P,cta_text:(a.textContent||'').trim().slice(0,60),link_url:href||null,data_service:a.getAttribute('data-service')||c.service,data_city:a.getAttribute('data-city')||c.city});}catch(err){log('click err',err);}},true);
document.addEventListener('submit',function(e){try{var f=e.target;if(!f||f.tagName!=='FORM')return;injectHidden(f);var hero=!!(f.closest&&f.closest('.hero,#hero'));push(hero?'hero_form_submit':'inspection_form_submit',{form_id:f.id||null,cta_position:hero?'hero':'body'});}catch(err){log('submit err',err);}},true);
captureUTM();captureLanding();
if(document.readyState!=='loading'){injectAll();}else{document.addEventListener('DOMContentLoaded',injectAll);}
log('init',ctxFor());
})();